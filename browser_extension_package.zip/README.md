# Browser Extension (Starter)

This is a minimal Chrome extension starter for LinkedIn Automation.

## What it does now

- Extension install is free.
- Actions are credit-based (server-side wallet).
- When credits are exhausted, extension receives redirect URL and sends user to pricing page.
- Stores API base URL and dashboard bearer token in extension local storage.
- Starts extension session and receives scoped extension token.
- Checks extension action credit cost.
- Consumes extension credits for quick comment draft action.
- Checks `/license/status` from popup.
- Quick links to dashboard and pricing page.

## Load in Chrome

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click `Load unpacked`.
4. Select this folder: `browser_extension`.

## Frontend Entry (Free Flow)

- Open extension setup page from landing CTA:
	- `/extension.html`
- This page provides:
	- source zip download,
	- extension folder link,
	- `chrome://extensions` instructions.

## Usage

1. Open extension popup.
2. Set API base, default: `https://linkedin-automation-8tng.onrender.com/api`.
3. Paste dashboard `app_auth_token`.
4. Click `Save`.
5. Click `Check License`.
6. Click `Start Extension Session`.
7. Use `Check Draft Cost` and `Consume Draft Credit`.

## Next planned scope

- Add login flow to fetch token from API directly.
- Add start/stop command actions for local agent.
- Add simple history of recent checks.
